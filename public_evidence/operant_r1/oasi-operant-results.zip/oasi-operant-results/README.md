# OASI bounded host experiment: results-only research artifact

This artifact makes the **readback of derived results** reproducible offline. It
does not contain the experiment implementation and cannot reproduce the campaign.
One completed local campaign is described, with no new campaign executed for this
release. The newly written passive reader and its tests operate only on JSON data.

## Denominators and findings

The dataset contains 22 episodes: 2 acquisition episodes, 16 transfer episodes
(4 unique situations paired across 4 controllers), and 4 control episodes.
The four situations combine input sizes 6 or 8 with unchanged capacity or a
reservation after the first effective flush. They are not 16 independent situations.

The reader checks exact ordered outputs for all 16 transfer episodes, 171 total
guard proposals, an admitted initial request of TWO with the acquired policy
versus ONE under the conservative no-skill ablation, and two matched feedback
contrasts after capacity reservation. The no-skill arm is an ablation, not the
strongest classical comparator. The acquired tree's action is checked on every
applicable recorded state and against minimum work on 42 development states;
policy acquisition itself is not rerun. The open-loop diagnostic is refused
without an effect on its final inadmissible request. In the drift control, an
effect occurs at work cost 9 versus prediction 4, followed by quarantine; the
following control has no effects. This is detection after the first discrepant
effect, not prediction or prevention of that effect.

| Situation | OASI | Conventional option | Planner | Cache + replanning |
|---|---:|---:|---:|---:|
| 6, stable | 18 | 18 | 18 | 18 |
| 6, reduced | 26 | 26 | 24 | 24 |
| 8, stable | 24 | 24 | 24 | 24 |
| 8, reduced | 36 | 36 | 34 | 34 |
| Total | 104 | 104 | 100 | 100 |

OASI and the conventional option have identical recorded action trajectories in
all 4 situations. OASI uses 4 more application work units than planner/cache
over these 16 transfer episodes. Acquisition adds 25 work units, outside that
transfer table. No comparative superiority, scientific originality, general
utility or adoption is established. No timing or energy advantage is claimed.

## Offline commands

Python 3.9 or later, standard library only. In a fresh extraction directory:

```text
python -B -E -s -S verify_results.py
python -B -E -s -S -m unittest -v test_reader
```

The first command checks the exact allowlist, hashes, schemas, action transitions,
guard/effect agreement, output bytes/order, work matrix, declared policy, controls
and expected report. Exit 0 reports PASS_RESULTS_READBACK. The second executes
one positive data case, 17 semantic negative variants and 3 malformed-JSON cases,
without executing a plant, service, learner or campaign. The test runner reports
3 test methods; its subcase counts are not separate experimental episodes.

## Disclosure and evidence boundaries

The primitive task outputs x*x+3*x+7 modulo 2^32 as four-byte big-endian records.
The represented capacity is a three-slot, process-owned pool of four-byte buffers,
not all interpreter memory, host RAM, a physical machine reconfiguration or a guest.

`results.json` is an explicit allowlist projection of existing local receipts:
inputs, abstract states, requested actions, legal sets, admitted effects, work,
predictions, ordered bytes, labels and the learned model/tree. Original source
code, runtime files, host identifiers, PIDs, timestamps, timing measurements,
process telemetry, account/profile information, private directories, historical
project materials and third-party AI transcripts are absent. Only a newly written
passive verifier and its tests are supplied as code.

`PROJECTION.json` records original hash commitments, the projected data hash and
the exact field selection. It does not make the original private receipt chain
reconstructible. Hashes establish consistency against the supplied seal, not
authenticity, real execution, owner identity, original field-preservation or
independent validation. Those require separate evidence. The projection is not
an original receipt and this new reader is not an independent campaign execution.

In particular, public checks establish consistency of the supplied mathematical
states, outputs, work counts, policy and declared control labels. They do not
establish actual bytearray ownership, distinct operating-system processes,
restart persistence of quarantine, or acquisition through the omitted runtime.
The equality of selected fields to private originals and the original quarantine
hash-link were checked locally during packaging only. Their original source
binding is not publicly reconstructible from this reduced artifact.

No claim is made of a general operating system, AGI, hostile isolation, hardware
recovery, power-loss durability, guest/guardian execution, throughput or energy
benefit, independent replication, institutional endorsement or adoption.

## Scope and proposed licenses

The exact public allowlist is `MANIFEST.json` plus its nine listed files.
`LICENSE_PROPOSAL.md` proposes Apache-2.0 for the two new Python files and CC BY 4.0
for this text and derived data. These grants activate only upon the owner's
decision identifying this exact archive SHA-256 and scopes. No license for
historical/private software is requested, inferred or included. Until that
decision, this is a proposed release, not a licensed public distribution.
