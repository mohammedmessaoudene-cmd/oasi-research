"""New passive-reader tests. No body, service, runtime or campaign execution.

Proposed Apache-2.0; exact-seal owner approval is required by LICENSE_PROPOSAL.md.
"""
import copy
from pathlib import Path
import unittest

import verify_results as reader


class PassiveReaderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original = reader.parse((Path(__file__).absolute().parent/'results.json').read_bytes())

    def test_complete_projection_passes(self):
        report = reader.check_data(copy.deepcopy(self.original))
        self.assertEqual(report['status'],'PASS_RESULTS_READBACK')
        self.assertEqual(report['transfer_work_totals'],{'oasi':104,'option':104,'planner':100,'cache':100})
        self.assertEqual(report['guard_proposals'],171)

    def test_semantic_negative_controls(self):
        def episode(data,index=2):return data['episodes'][index]
        def step(data):return episode(data)['trace'][0]
        def output(data):episode(data)['delivered_hex']='00'
        def action(data):step(data)['action']='ONE'
        def cost(data):step(data)['cost']=5
        def legal(data):step(data)['legal']=['TWO']
        def effect(data):step(data)['effect']=False
        def state(data):step(data)['after']=[5,1,3]
        def matrix(data):episode(data)['arm']='planner'
        def denominator(data):data['episodes'].pop()
        def corpus(data):episode(data)['values'][0]+=1
        def completion(data):episode(data)['trace'].pop()
        def drift(data):episode(data,20)['status']='COMPLETE'
        def revoke(data):data['quarantine']['blocks_episode_id']=20
        def revoked_effect(data):episode(data,21)['trace']=copy.deepcopy(episode(data,20)['trace'])
        def model(data):data['policy']['model']['TWO']['cost']=3
        def tree(data):data['policy']['tree']={'action':'ONE'}
        def telemetry(data):episode(data)['process_id']=123
        def wrong_type(data):episode(data)['capacity']=True
        mutators = (output,action,cost,legal,effect,state,matrix,denominator,corpus,
                    completion,drift,revoke,revoked_effect,model,tree,telemetry,wrong_type)
        for mutate in mutators:
            with self.subTest(case=mutate.__name__):
                data = copy.deepcopy(self.original)
                mutate(data)
                with self.assertRaises((ValueError,TypeError,KeyError,IndexError)):
                    reader.check_data(data)

    def test_duplicate_and_nonfinite_json_rejected(self):
        for raw in ('{"a":1,"a":2}','{"a":NaN}','{"a":Infinity}'):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                reader.parse(raw)


if __name__ == '__main__':
    unittest.main()
