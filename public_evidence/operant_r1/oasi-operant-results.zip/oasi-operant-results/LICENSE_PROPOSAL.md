# Exact-seal license decision proposal

Status: PENDING_OWNER_APPROVAL_OF_EXACT_ARCHIVE_SEAL.

This document does not itself activate a license grant. The owner may approve
publication and the following licenses for the exact final archive SHA-256
presented for decision. The owner decision must name the archive hash and both
scopes; publication of matching bytes together with that decision activates the
specified grants. No standing grant for any broader folder or historical code
is implied. If bytes change, the revised seal requires a new decision.

Proposed scopes:

- Apache License 2.0: `verify_results.py` and `test_reader.py`, newly written
  passive readback/test code, without incorporated historical implementation.
- Creative Commons Attribution 4.0 International: `README.md`, `results.json`,
  `PROJECTION.json`, `EXPECTED_REPORT.json`, and original explanatory text in this
  artifact. Attribution should identify the artifact title and the owner-approved
  creator/publication record supplied with the decision, link the license, and
  indicate subsequent changes. No creator identity or publication DOI is invented.
- `MANIFEST.json` is a factual inventory; its packaging scope follows the data.
- Standard license texts/notices describe the proposed terms and are not claims
  of authorship over the licenses themselves.

The standard Apache-2.0 terms are included under `LICENSES/Apache-2.0.txt`.
The CC BY 4.0 notice and permanent legal-code reference are included under
`LICENSES/CC-BY-4.0-NOTICE.txt`. Neither presence bypasses the exact-seal decision.
The proposal follows a split code/data licensing convention, and does not license,
represent ownership over, or require disclosure of any old runtime or private code.
