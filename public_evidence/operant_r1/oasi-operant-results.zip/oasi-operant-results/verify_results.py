"""New passive reader for a results-only projection. No experiment implementation.

Proposed code license: Apache-2.0, subject to the exact-seal owner decision
described in LICENSE_PROPOSAL.md. Not a currently activated license grant.
"""
import hashlib
import json
from pathlib import Path
import stat
import sys


class Rejected(ValueError):
    pass


def insist(condition, message):
    if not condition:
        raise Rejected(message)


def same(left, right):
    return json.dumps(left, sort_keys=True) == json.dumps(right, sort_keys=True)


def integer(value, low, high, message):
    insist(type(value) is int and low <= value <= high, message)


def exact_keys(obj, keys, message):
    insist(type(obj) is dict and set(obj) == set(keys.split()), message)


def unique(items):
    result = {}
    for key, value in items:
        insist(key not in result, 'duplicate JSON field')
        result[key] = value
    return result


def parse(raw):
    def nonfinite(_):
        raise Rejected('nonfinite JSON')
    return json.loads(raw, object_pairs_hook=unique, parse_constant=nonfinite)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe_file(path):
    info = path.lstat()
    insist(stat.S_ISREG(info.st_mode) and not (getattr(info,'st_file_attributes',0)&0x400)
           and 0 < info.st_size <= 2**20, 'not a bounded ordinary file')
    return path.read_bytes()


def admitted(state):
    n, queued, capacity = state
    result = set()
    if n and queued < capacity:
        result.add('ONE')
    if n >= 2 and capacity - queued >= 2:
        result.add('TWO')
    if queued:
        result.add('FLUSH')
    return result


def next_state(state, action):
    n, queued, capacity = state
    if action == 'FLUSH':
        return [n, 0, capacity]
    width = 1 if action == 'ONE' else 2
    return [n-width, queued+width, capacity]


def facts(state):
    n, queued, capacity = state
    return {'WORK':n>0, 'MULTI':n>=2, 'NONEMPTY':queued>0,
            'SPACE':queued<capacity, 'ROOM2':capacity-queued>=2,
            'CAP2':capacity>=2, 'EVEN':n%2==0}


def check_tree(tree):
    def walk(node, depth):
        insist(type(node) is dict and depth <= 5, 'policy depth/schema')
        if set(node) == {'action'}:
            insist(node['action'] in ('ONE','TWO','FLUSH'), 'policy leaf')
            return 1
        exact_keys(node, 'if yes no', 'policy branch')
        insist(type(node['if']) is str and node['if'] in facts([0,0,1]), 'policy predicate')
        return 1 + walk(node['yes'],depth+1) + walk(node['no'],depth+1)
    count = walk(tree,0)
    insist(1 < count <= 63, 'policy node budget/nonconstant')
    return count


def requested(tree, state):
    current = tree
    while 'if' in current:
        current = current['yes'] if facts(state)[current['if']] else current['no']
    return current['action']


BASE_WORK = {'ONE':3, 'TWO':4, 'FLUSH':2}


def check_episode(row):
    exact_keys(row, 'id stage arm case values capacity perturb status delivered_hex work_units trace',
               'episode projection fields')
    integer(row['id'],0,21,'episode ID')
    integer(row['capacity'],3,3,'initial capacity')
    insist(type(row['perturb']) is bool, 'perturbation type')
    values = row['values']
    insist(type(values) is list and len(values) in (3,4,6,8), 'input size')
    insist(all(type(x) is int for x in values)
           and same(values,[13+7*i+i*i for i in range(len(values))]), 'input corpus')
    trace = row['trace']
    insist(type(trace) is list and len(trace) <= 64, 'trace bounds')
    current = [len(values),0,3]
    committed = 0
    work = 0
    generated = bytearray()
    rejected_at = []
    residual_at = []
    reserved = False
    effects = 0
    for index, step in enumerate(trace):
        exact_keys(step, 'before action after legal effect cost predicted', 'step projection fields')
        insist(same(step['before'],current), 'state discontinuity')
        action = step['action']
        insist(type(action) is str and action in BASE_WORK, 'unknown action')
        legal = admitted(current)
        insist(type(step['legal']) is list and len(step['legal']) == len(legal)
               and all(type(x) is str for x in step['legal']) and set(step['legal']) == legal,
               'legal action set')
        insist(type(step['effect']) is bool and step['effect'] == (action in legal), 'guard/effect')
        integer(step['cost'],0,9,'work type/range')
        effective = step['effect']
        after = next_state(current,action) if effective else current.copy()
        insist(same(step['after'],after), 'transition')
        expected_cost = (9 if row['arm']=='drift' and action=='TWO' else BASE_WORK[action]) if effective else 0
        insist(step['cost'] == expected_cost, 'performed work')
        work += expected_cost
        if effective:
            effects += 1
            if action == 'FLUSH':
                for x in values[committed:committed+current[1]]:
                    value = (pow(x,2) + 3*x + 7) % 4294967296
                    generated.extend(value.to_bytes(4,'big'))
                committed += current[1]
            if row['stage'] == 'acquisition':
                insist(step['predicted'] is None, 'acquisition prediction')
            else:
                insist(same(step['predicted'],[after,BASE_WORK[action]]), 'predicted state/work')
                if expected_cost != BASE_WORK[action]:
                    residual_at.append(index)
        else:
            insist(step['predicted'] is None, 'prediction despite refused request')
            rejected_at.append(index)
        current = after.copy()
        if row['perturb'] and not reserved and effective and action == 'FLUSH':
            insist(current[1] == 0 and current[2] == 3, 'reservation boundary')
            current[2] = 1
            reserved = True
        insist(len(values) == current[0]+current[1]+committed, 'record conservation')
    insist(type(row['delivered_hex']) is str and row['delivered_hex'] == generated.hex(), 'exact ordered output')
    insist(type(row['work_units']) is int and row['work_units'] == work, 'episode work total')
    status = row['status']
    if status == 'COMPLETE':
        insist(current[:2] == [0,0] and len(generated) == 4*len(values)
               and not rejected_at and not residual_at, 'false completion')
    elif status == 'GUARD_REFUSAL':
        insist(bool(trace) and rejected_at == [len(trace)-1] and not residual_at, 'false guard stop')
    elif status == 'QUARANTINE':
        insist(bool(trace) and residual_at == [len(trace)-1] and not rejected_at, 'false observed quarantine')
    elif status == 'REVOKED':
        insist(row['arm'] == 'revoked' and not trace and not generated and work == 0, 'effect after revocation')
    else:
        raise Rejected('unknown episode status')
    return effects


def check_data(data):
    exact_keys(data, 'schema scope policy quarantine episodes', 'data projection fields')
    insist(data['schema'] == 'OASI_RESULTS_ONLY_1', 'data schema')
    insist(data['scope'] == 'bounded host-process three-slot pool; readback only', 'scope')
    policy = data['policy']
    exact_keys(policy, 'model tree source_episode_ids', 'policy projection fields')
    insist(same(policy['source_episode_ids'],[0,1]), 'acquisition provenance labels')
    expected_model = {'ONE':{'work':1,'queue':'add','cost':3},
                      'TWO':{'work':2,'queue':'add','cost':4},
                      'FLUSH':{'work':0,'queue':'clear','cost':2}}
    insist(same(policy['model'],expected_model), 'bounded empirical transition model')
    nodes = check_tree(policy['tree'])
    rows = data['episodes']
    insist(type(rows) is list and len(rows) == 22, '22 episode denominator')
    cases = ('n6-static','n6-shrink','n8-static','n8-shrink')
    arms = ('oasi','option','planner','cache')
    schedule = [('acquisition','explore','development-odd',3,False),
                ('acquisition','explore','development-even',4,False)]
    schedule.extend(('transfer',arm,case,int(case[1]),case.endswith('shrink')) for case in cases for arm in arms)
    schedule.extend(('control',arm,'n6-shrink' if arm=='open_loop' else 'n6-static',6,arm=='open_loop')
                    for arm in ('no_skill','open_loop','drift','revoked'))
    effects = 0
    for index, (row, design) in enumerate(zip(rows,schedule)):
        insist(type(row) is dict and type(row.get('id')) is int and row['id'] == index, 'episode order/identity')
        effects += check_episode(row)
        insist(same([row['stage'],row['arm'],row['case'],len(row['values']),row['perturb']],list(design)),
               'fixed schedule/matrix')
        if index < 18 or row['arm'] == 'no_skill':
            insist(row['status'] == 'COMPLETE', 'incomplete acquisition/transfer/ablation')
        if row['arm'] in ('oasi','option','drift'):
            insist(all(requested(policy['tree'],step['before']) == step['action'] for step in row['trace']),
                   'persisted tree request disagreement')
    # Model support is checked against each observed acquisition effect.
    calibration = {}
    for row in rows[:2]:
        for step in row['trace']:
            action = step['action']
            measured = {'work':step['before'][0]-step['after'][0],
                        'queue':'clear' if action == 'FLUSH' else 'add','cost':step['cost']}
            insist(action not in calibration or same(calibration[action],measured), 'inconsistent acquisition')
            calibration[action] = measured
    insist(same(calibration,policy['model']), 'model not supported by acquisition')
    # Independently recompute minimum work on the 42 declared development states.
    memo = {}
    def best(state):
        state = tuple(state)
        if state in memo:
            return memo[state]
        choices = admitted(state)
        cost = min((BASE_WORK[action]+best(next_state(state,action)) for action in choices), default=0)
        memo[state] = cost
        return cost
    development = [[n,q,c] for c in (1,2,3) for n in range(5) for q in range(c+1) if (n,q)!=(0,0)]
    for state in development:
        action = requested(policy['tree'],state)
        insist(action in admitted(state) and BASE_WORK[action]+best(next_state(state,action)) == best(state),
               'policy not minimum-work on development lattice')
    matrix = {(row['case'],row['arm']):row for row in rows[2:18]}
    no_skill, open_loop, drift, revoked = rows[18:]
    with_skill = matrix[('n6-static','oasi')]
    a,b = with_skill['trace'][0],no_skill['trace'][0]
    insist(same(a['before'],b['before']) and len(a['legal']) >= 2 and a['effect'] and b['effect']
           and a['action']=='TWO' and b['action']=='ONE', 'matched legal pre-guard ablation contrast')
    for n in (6,8):
        stable = matrix[(f'n{n}-static','oasi')]['trace']
        shrink = matrix[(f'n{n}-shrink','oasi')]['trace']
        differences = [(a,b) for a,b in zip(stable,shrink) if a['action'] != b['action']]
        insist(bool(differences), 'missing capacity feedback contrast')
        a,b = differences[0]
        insist(same(a['before'][:2],b['before'][:2]) and a['before'][2]==3 and b['before'][2]==1
               and a['effect'] and b['effect'], 'invalid paired capacity contrast')
    insist(open_loop['status']=='GUARD_REFUSAL' and open_loop['trace'][-1]['action']=='TWO'
           and not open_loop['trace'][-1]['effect'], 'open-loop diagnostic control')
    insist(drift['status']=='QUARANTINE' and drift['trace'][-1]['action']=='TWO'
           and drift['trace'][-1]['cost']==9 and drift['trace'][-1]['predicted'][1]==4
           and revoked['status']=='REVOKED' and not revoked['trace'], 'drift then persistent revocation')
    insist(same(data['quarantine'],{'source_episode_id':20,'blocks_episode_id':21,
                                  'reason':'MEASURED_TRANSITION_OR_WORK_MISMATCH'}), 'revocation projection link')
    def trajectory(row):
        return [[s['before'],s['action'],s['after'],s['cost'],s['effect']] for s in row['trace']]
    costs = {case:{arm:matrix[(case,arm)]['work_units'] for arm in arms} for case in cases}
    return {'status':'PASS_RESULTS_READBACK','episodes':22,'acquisition_episodes':2,
            'transfer_episodes':16,'unique_transfer_situations':4,'controllers_per_situation':4,
            'control_episodes':4,'complete_transfer_outputs':16,'guard_proposals':sum(len(r['trace']) for r in rows),
            'effective_actions':effects,'policy_nodes':nodes,'development_states_checked':len(development),
            'acquisition_work_units':sum(r['work_units'] for r in rows[:2]),
            'transfer_work_matrix':costs,'transfer_work_totals':{arm:sum(costs[c][arm] for c in cases) for arm in arms},
            'oasi_option_equal_trajectories':sum(trajectory(matrix[(c,'oasi')])==trajectory(matrix[(c,'option')]) for c in cases),
            'pre_guard_initial_requests':{'with_skill':a0(with_skill),'without_skill':a0(no_skill)},
            'paired_capacity_feedback_cases':2,'open_loop_diagnostic':'GUARD_REFUSAL_NO_EFFECT_ON_REFUSED_REQUEST',
            'drift_control':'OBSERVED_EFFECT_THEN_QUARANTINE','following_control':'REVOKED_WITH_ZERO_EFFECTS',
            'superiority':'NOT_ESTABLISHED','originality':'NOT_ESTABLISHED',
            'boundary':'Derived local results readback only; not campaign reproduction, external validation or original-chain reconstruction.'}


def a0(row):
    return row['trace'][0]['action']


def verify_package(root):
    for node in (*reversed(root.parents),root):
        info = node.lstat()
        insist(not stat.S_ISLNK(info.st_mode) and not (getattr(info,'st_file_attributes',0)&0x400), 'linked path')
    actual = set()
    for node in root.rglob('*'):
        info = node.lstat()
        insist(not stat.S_ISLNK(info.st_mode) and not (getattr(info,'st_file_attributes',0)&0x400), 'linked entry')
        insist(stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode), 'special entry')
        if node.is_file():
            safe_file(node)
            actual.add(node.relative_to(root).as_posix())
    manifest = parse(safe_file(root/'MANIFEST.json'))
    exact_keys(manifest, 'schema files', 'manifest fields')
    insist(manifest['schema']=='OASI_RESULTS_MANIFEST_1' and type(manifest['files']) is dict, 'manifest schema')
    insist(actual == set(manifest['files']) | {'MANIFEST.json'}, 'unexpected/missing file')
    required = {'README.md','LICENSE_PROPOSAL.md','LICENSES/Apache-2.0.txt','LICENSES/CC-BY-4.0-NOTICE.txt',
                'verify_results.py','test_reader.py','results.json','PROJECTION.json','EXPECTED_REPORT.json'}
    insist(set(manifest['files']) == required, 'release allowlist')
    for name, entry in manifest['files'].items():
        exact_keys(entry,'bytes sha256','manifest entry')
        insist(type(entry['bytes']) is int and entry['bytes'] == (root/name).stat().st_size
               and entry['sha256'] == sha(safe_file(root/name)), 'file hash/size mismatch: '+name)
    projection = parse(safe_file(root/'PROJECTION.json'))
    insist(projection['schema']=='OASI_RESULTS_PROJECTION_1' and projection['public_data_sha256']==sha(safe_file(root/'results.json')),
           'projection data commitment')
    insist(projection['license_decision']=='PENDING_OWNER_APPROVAL_OF_EXACT_ARCHIVE_SEAL', 'license decision scope')
    report = check_data(parse(safe_file(root/'results.json')))
    insist(same(report,parse(safe_file(root/'EXPECTED_REPORT.json'))), 'expected report mismatch')
    return report


if __name__ == '__main__':
    try:
        insist(len(sys.argv)==1 and sys.flags.dont_write_bytecode, 'usage: python -B -E -s -S verify_results.py')
        print(json.dumps(verify_package(Path(__file__).absolute().parent),sort_keys=True))
    except (ValueError,TypeError,KeyError,OSError,IndexError,RecursionError) as error:
        print(json.dumps({'status':'REJECTED','reason':str(error)}))
        sys.exit(1)
